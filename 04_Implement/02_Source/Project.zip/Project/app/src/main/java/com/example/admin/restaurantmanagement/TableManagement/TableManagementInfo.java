package com.example.admin.restaurantmanagement.TableManagement;

public class TableManagementInfo {

    String tableName;

    public TableManagementInfo(String tableName) {

        this.tableName = tableName;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
}
